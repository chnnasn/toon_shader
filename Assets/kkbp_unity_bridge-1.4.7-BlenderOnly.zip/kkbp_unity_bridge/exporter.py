"""KKBP color-basis exporter. Never saves or edits the source .blend.

Each light/dark output is represented by a constant RGB texture plus up to eight
RGB response textures. Two independent mixed-color probes reject non-affine or
channel-mixing graphs. Baking resolves the actual KKBP masks and UV transforms;
there is no guessed texture filename or hardcoded body UV layout.
"""
import json
from pathlib import Path
import shutil
import uuid

import bpy
import numpy as np

DEFAULT_CHANNELS = ('Nail color (multiplied)', 'Nipple base', 'Nipple base 2', 'Nipple shine', 'Nipple rim')


def is_clothing(obj):
    group = obj.get('part_group')
    if group in ('Body', 'Hair'): return False
    if group in ('Clothing', 'Accessories'): return True
    return bool(obj.get('outfit')) and not obj.get('hair')


def enum_set(owner, prop, value):
    values = {i.identifier for i in owner.bl_rna.properties[prop].enum_items}
    if value not in values:
        raise RuntimeError(f'{prop}: {value} unavailable in Blender {bpy.app.version_string}')
    setattr(owner, prop, value)


def variant_socket(mat, variant):
    """Identify KKBP's semantic group interface, not localized built-in node names."""
    if not mat or not mat.node_tree:
        return None
    label = 'Light colors' if variant == 'light' else 'Dark colors'
    image_label = 'Light image' if variant == 'light' else 'Dark image'
    for n in mat.node_tree.nodes:
        if n.type != 'GROUP':
            continue
        for name in (label, image_label):
            s = n.inputs.get(name)
            if s and s.is_linked:
                return s.links[0].from_socket
    return None


def editable_source(mat, channels):
    s = variant_socket(mat, 'light')
    if s and any(s.node.inputs.get(c) for c in channels):
        return mat
    # Only use a unique editable material with the same KKBP material AND character ID.
    # Never fall back to the library's unconfigured "KK Body" template.
    if mat.get('id') and mat.get('name'):
        matches = []
        for candidate in bpy.data.materials:
            if candidate.get('id') != mat.get('id') or candidate.get('name') != mat.get('name'):
                continue
            socket = variant_socket(candidate, 'light')
            if socket and any(socket.node.inputs.get(c) for c in channels):
                matches.append(candidate)
        if len(matches) == 1:
            return matches[0]
        if len(matches) > 1:
            raise RuntimeError(f'{mat.name}: multiple editable materials; assign the desired one first')
    if mat.get('id') in ('cf_m_body', 'cm_m_body'):
        raise RuntimeError(f'{mat.name}: use KKBP Edit Material before exporting; baked body has no color controls')
    return mat


def make_bake_mesh(scene, objects, material, temp_material):
    """One disconnected mesh containing only this material's faces, with all named UVs."""
    vertices, faces, uvs = [], [], {}
    first_uv = None
    for obj in objects:
        slots = [i for i, slot in enumerate(obj.material_slots) if slot.material == material]
        polygons = [p for p in obj.data.polygons if p.material_index in slots]
        if not polygons:
            continue
        if not obj.data.uv_layers:
            raise RuntimeError(f'{obj.name}: UV0 is required')
        names = [u.name for u in obj.data.uv_layers]
        if first_uv is None:
            first_uv = names[0]
            uvs = {name: [] for name in names}
        if list(uvs) != names:
            raise RuntimeError(f'{material.name}: meshes sharing a material must have matching named UV layers')
        offset = len(vertices)
        vertices.extend(tuple(v.co) for v in obj.data.vertices)
        for p in polygons:
            faces.append([offset + v for v in p.vertices])
            for uv in obj.data.uv_layers:
                uvs[uv.name].extend(tuple(uv.data[i].uv) for i in p.loop_indices)
    mesh = bpy.data.meshes.new('KKBridge bake mesh')
    mesh.from_pydata(vertices, [], faces)
    for name, coords in uvs.items():
        layer = mesh.uv_layers.new(name=name)
        layer.data.foreach_set('uv', np.array(coords, dtype=np.float32).ravel())
    original_uv=np.array(uvs[first_uv],dtype=np.float32)
    low=np.minimum(original_uv.min(axis=0),0)
    high=np.maximum(original_uv.max(axis=0),1)
    scale=1/(high-low); offset=-low*scale
    bake_uv=mesh.uv_layers.new(name='KKBridgeBake')
    bake_uv.data.foreach_set('uv',(original_uv*scale+offset).ravel())
    mesh.uv_layers.active_index = 0
    mesh.uv_layers[0].active_render = True
    mesh.materials.append(temp_material)
    obj = bpy.data.objects.new('KKBridge bake object', mesh)
    scene.collection.objects.link(obj)
    obj['bridge_uv']=[float(scale[0]),float(scale[1]),float(offset[0]),float(offset[1])]
    obj['bridge_bake_uv']=bake_uv.name
    return obj


class Baker:
    def __init__(self, scene, obj, mat, size):
        self.scene, self.obj, self.mat, self.size = scene, obj, mat, size
        self.tree = mat.node_tree
        for n in list(self.tree.nodes):
            if n.type == 'OUTPUT_MATERIAL':
                self.tree.nodes.remove(n)
        out = self.tree.nodes.new('ShaderNodeOutputMaterial')
        self.emission = self.tree.nodes.new('ShaderNodeEmission')
        self.tree.links.new(self.emission.outputs[0], out.inputs['Surface'])
        self.target = self.tree.nodes.new('ShaderNodeTexImage')
        self.tree.nodes.active = self.target
        self.image = bpy.data.images.new('KKBridge bake', width=size, height=size, alpha=True, float_buffer=True)
        enum_set(self.image.colorspace_settings, 'name', 'Non-Color')
        self.target.image = self.image

    def bake(self, socket=None, value=None):
        for link in list(self.emission.inputs['Color'].links):
            self.tree.links.remove(link)
        if socket:
            self.tree.links.new(socket, self.emission.inputs['Color'])
        else:
            self.emission.inputs['Color'].default_value = value
        self.tree.nodes.active = self.target
        self.obj.select_set(True)
        bpy.context.view_layer.objects.active = self.obj
        self.mat.update_tag()
        bpy.context.view_layer.update()
        bpy.ops.object.bake(type='EMIT',uv_layer=self.obj['bridge_bake_uv'])
        pixels = np.empty(self.size * self.size * 4, dtype=np.float32)
        self.image.pixels.foreach_get(pixels)
        return pixels.reshape((-1, 4)).copy()

    def save(self, array, path):
        self.image.pixels.foreach_set(np.asarray(array, dtype=np.float32).ravel())
        self.image.update()
        enum_set(self.image, 'file_format', 'OPEN_EXR')
        self.image.filepath_raw = str(path)
        self.image.save()

    def close(self):
        bpy.data.images.remove(self.image)


def alpha_socket(mat):
    for n in mat.node_tree.nodes:
        if n.type != 'GROUP':
            continue
        # Resolve KKBP's actual alpha output inside a private copy of the combine group.
        if n.inputs.get('Light colors') or n.inputs.get('Light image'):
            group = n.node_tree.copy()
            mix = next((x for x in group.nodes if x.type == 'MIX_SHADER'), None)
            if not mix or not mix.inputs[0].is_linked:
                bpy.data.node_groups.remove(group)
                raise RuntimeError('Unsupported KKBP alpha combine graph')
            group.interface.new_socket(name='Bridge opacity', in_out='OUTPUT', socket_type='NodeSocketFloat')
            output = next(x for x in group.nodes if x.type == 'GROUP_OUTPUT' and x.is_active_output)
            # KKBP mixes transparent (first) and emission (second) using opacity.
            transparent = mix.inputs[1].links[0].from_node if mix.inputs[1].is_linked else None
            if not transparent or transparent.type != 'BSDF_TRANSPARENT':
                bpy.data.node_groups.remove(group)
                raise RuntimeError('Unsupported KKBP transparency order')
            group.links.new(mix.inputs[0].links[0].from_socket, output.inputs['Bridge opacity'])
            n.node_tree = group
            return n.outputs['Bridge opacity'], group
    return None, None


def export_material(scene, objects, original, channels, size, directory, number):
    source = editable_source(original, channels)
    mat = source.copy()
    obj = None
    baker = None
    alpha_group = None
    slug = f'm{number:03d}'
    record = {'name': original.name, 'sourceMaterial': source.name, 'channels': [], 'variants': [], 'warnings': [], 'hair':bool(original.get('hair')), 'skin': original.get('id') in ('cf_m_body','cm_m_body','cf_m_face_00')}
    try:
        obj = make_bake_mesh(scene, objects, original, mat)
        record['uvTransform']=dict(zip(('x','y','z','w'),obj['bridge_uv']))
        baker = Baker(scene, obj, mat, size)
        for variant in ('light', 'dark'):
            socket = variant_socket(mat, variant)
            if socket is None:
                raise RuntimeError(f'{original.name}: no KKBP {variant} color output; use KKBP materials before atlas/finalization')
            node = socket.node
            controls = [node.inputs[c] for c in channels if node.inputs.get(c) and node.inputs[c].type == 'RGBA']
            if variant == 'light':
                record['channels'] = [s.name for s in controls]
            elif record['channels'] != [s.name for s in controls]:
                raise RuntimeError(f'{original.name}: light/dark editable inputs differ')
            if any(s.is_linked for s in controls):
                raise RuntimeError(f'{original.name}: editable color inputs must be constant colors, not linked nodes')
            defaults = [list(s.default_value) for s in controls]
            for s in controls:
                s.default_value = (0, 0, 0, 1)
            base = baker.bake(socket)
            base[:, 3] = 1
            base_file = f'{slug}_{variant}_base.exr'
            baker.save(base, directory / base_file)
            responses = []
            response_files = []
            for i, s in enumerate(controls):
                s.default_value = (1, 1, 1, 1)
                response = baker.bake(socket) - base
                response[:, 3] = 1
                responses.append(response)
                filename = f'{slug}_{variant}_weight{i}.exr'
                response_files.append(filename)
                baker.save(response, directory / filename)
                s.default_value = (0, 0, 0, 1)
                if float(np.max(np.abs(response[:, :3]))) < 1e-5:
                    record['warnings'].append(f'{variant}: {s.name} has no visible influence with current masks/settings')
            errors = []
            probes = [defaults, [[(i*.17+.21)%1, (i*.31+.47)%1, (i*.13+.73)%1, 1] for i in range(len(controls))]]
            for colors in probes if controls else []:
                expected = base[:, :3].copy()
                for s, color, weight in zip(controls, colors, responses):
                    s.default_value = color
                    expected += weight[:, :3] * np.array(color[:3])
                actual = baker.bake(socket)[:, :3]
                error = float(np.max(np.abs(actual - expected)))
                errors.append(error)
                if not np.isfinite(error) or error > .003:
                    raise RuntimeError(f'{original.name}/{variant}: color reconstruction error {error:.6f}; nonlinear/custom nodes are unsupported')
            for s, color in zip(controls, defaults):
                s.default_value = color
            record['variants'].append({'name': variant, 'base': base_file, 'weights': response_files,
                                       'colors': [{'r':c[0],'g':c[1],'b':c[2],'a':c[3]} for c in defaults],
                                       'maxValidationError': max(errors, default=0)})
        opacity, alpha_group = alpha_socket(mat)
        if opacity:
            alpha = baker.bake(opacity)
        else:
            raise RuntimeError(f'{original.name}: no recognized KKBP opacity graph')
        record['opacity'] = f'{slug}_opacity.exr'
        record['cutout'] = bool(np.min(alpha[:,0]) < .99)
        baker.save(alpha, directory / record['opacity'])
        print('KKBRIDGE_MATERIAL', original.name, record['channels'], flush=True)
        return record
    finally:
        if baker: baker.close()
        if obj:
            mesh=obj.data; bpy.data.objects.remove(obj,do_unlink=True); bpy.data.meshes.remove(mesh)
        bpy.data.materials.remove(mat)
        if alpha_group: bpy.data.node_groups.remove(alpha_group)


def export_bundle(context, filepath, resolution=1024, channels=DEFAULT_CHANNELS, direct_unity=False, objects_override=None):
    if context.mode != 'OBJECT':
        raise RuntimeError('Switch to Object Mode before exporting')
    if not 128 <= resolution <= 4096:
        raise ValueError('Resolution must be 128–4096')
    if len(channels) > 8 or len(set(channels)) != len(channels):
        raise ValueError('Choose up to eight unique color input names')
    objects = list(objects_override) if objects_override is not None else [o for o in context.selected_objects if o.type == 'MESH']
    if not objects:
        raise RuntimeError('Select the character mesh objects first')
    materials = list(dict.fromkeys(o.material_slots[p.material_index].material for o in objects for p in o.data.polygons if p.material_index < len(o.material_slots) and o.material_slots[p.material_index].material))
    if not materials:
        raise RuntimeError('Selected objects have no materials')
    # Fail before baking when body editing data has been discarded.
    for mat in materials: editable_source(mat, channels)
    path=Path(filepath).resolve().with_suffix('.fbx' if direct_unity else '.kkbridge')
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists() or path.with_suffix('').exists():
        raise RuntimeError('Choose a new bundle name; existing exports are never overwritten')
    # Inherit the output directory ACL. Windows tempfile.mkdtemp uses a private
    # owner-only ACL, preventing a Unity process running as another user reading it.
    stage=path.parent/('.kkbridge-'+uuid.uuid4().hex)
    stage.mkdir()
    original_meshes=set(bpy.data.meshes); original_armatures=set(bpy.data.armatures)
    scene=bpy.data.scenes.new('KKBridge temporary export')
    old_scene=context.window.scene
    created=[]; copied_data=[]
    try:
        context.window.scene=scene
        try: scene.render.engine='CYCLES'
        except TypeError as exc: raise RuntimeError('Cycles is required for texture baking') from exc
        scene.cycles.samples=1
        enum_set(scene.cycles,'device','CPU')
        scene.render.bake.use_clear=True
        scene.render.bake.margin=4
        scene.render.bake.use_selected_to_active=False
        textures=stage/'textures'; textures.mkdir()
        entries=[export_material(scene,objects,m,channels,resolution,textures,i) for i,m in enumerate(materials)]
        sources=set(objects)
        for obj in objects:
            p=obj.parent
            while p:
                sources.add(p);p=p.parent
            for mod in obj.modifiers:
                if mod.type=='ARMATURE' and mod.object: sources.add(mod.object)
        copies={}
        for source in sorted(sources,key=lambda o:o.name):
            clone=source.copy()
            if source.data:
                clone.data=source.data.copy();copied_data.append(clone.data)
            clone.animation_data_clear()
            if clone.type == 'MESH':
                used = sorted({p.material_index for p in clone.data.polygons})
                slots = [s.material for s in source.material_slots]
                if any(i >= len(slots) or slots[i] is None for i in used):
                    raise RuntimeError(f'{source.name}: faces without a material are unsupported')
                indices = [used.index(p.material_index) for p in clone.data.polygons]
                clone.data.materials.clear()
                for i in used: clone.data.materials.append(slots[i])
                for p, i in zip(clone.data.polygons, indices): p.material_index = i
                for slot in clone.material_slots: slot.link = 'DATA'
            scene.collection.objects.link(clone);created.append(clone);copies[source]=clone
            clone.hide_set(False);clone.hide_viewport=False;clone.hide_render=False
        for source,clone in copies.items():
            world=source.matrix_world.copy()
            clone.parent=copies.get(source.parent)
            clone.matrix_world=world
            for mod in clone.modifiers:
                if mod.type=='ARMATURE': mod.object=copies.get(mod.object)
            # Duplicate outline geometry is not exported; shading is owned by Unity.
            for mod in list(clone.modifiers):
                if mod.type!='ARMATURE': clone.modifiers.remove(mod)
            clone.select_set(True)
        export_meshes = [copies[o] for o in objects]
        for obj in scene.objects: obj.select_set(True)
        # Use only original material names. FBX contains mesh slots, not the private bake materials.
        bpy.context.view_layer.objects.active=export_meshes[0]
        model_filename=path.stem+'.fbx' if direct_unity else 'model.fbx'
        bpy.ops.export_scene.fbx(filepath=str(stage/model_filename),use_selection=True,
            object_types={'MESH','ARMATURE','EMPTY'},use_mesh_modifiers=False,
            add_leaf_bones=False,bake_anim=False,path_mode='STRIP',axis_forward='-Z',axis_up='Y')
        if direct_unity:
            from .unity_assets import write_unity_assets
            for entry in entries:
                entry['opacity']='textures/'+entry['opacity']
                for variant in entry['variants']:
                    variant['base']='textures/'+variant['base']
                    variant['weights']=['textures/'+p for p in variant['weights']]
            write_unity_assets(stage,model_filename,entries,resolution)
        prefix='' if direct_unity else path.stem+'/'
        for entry in entries:
            if direct_unity: continue
            entry['opacity']=prefix+'textures/'+entry['opacity']
            for variant in entry['variants']:
                variant['base']=prefix+'textures/'+variant['base']
                variant['weights']=[prefix+'textures/'+p for p in variant['weights']]
        report={'schemaVersion':1,'generator':'KKBP Unity Bridge 1.4.7',
                'parts':[],'meshes':[{'name':o.name,'category':o.get('kkbridge_category',''),'materialSlots':len(o.data.materials),'part':'Clothing' if is_clothing(o) else 'Body','uvLayers':[u.name for u in o.data.uv_layers],
                'shapeKeys':[k.name for k in o.data.shape_keys.key_blocks][1:] if o.data.shape_keys else [],
                'vertices':len(o.data.vertices)} for o in export_meshes],
                'blenderVersion':bpy.app.version_string,'resolution':resolution,
                'colorSpace':'linear','model':prefix+model_filename,'materials':entries,
                'limitations':['Lighting is URP toon lighting, not a port of the entire KKBP shader.',
                'Color inputs remain editable; fixed texture placement, intensity and overlays require re-export.',
                'Normal maps, outline modifiers, physics and animation clips are not exported by this version.']}
        if direct_unity:
            (stage/'export_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
        shutil.move(str(stage),str(path.with_suffix('')))
        if not direct_unity:
            path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
        return report
    finally:
        context.window.scene=old_scene
        for obj in list(scene.objects): bpy.data.objects.remove(obj,do_unlink=True)
        for data in set(bpy.data.meshes)-original_meshes: bpy.data.meshes.remove(data)
        for data in set(bpy.data.armatures)-original_armatures: bpy.data.armatures.remove(data)
        bpy.data.scenes.remove(scene)
        if stage.exists(): shutil.rmtree(stage)
