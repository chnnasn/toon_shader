bl_info = {
    'name': 'KKBP Unity Material Bridge', 'author': 'KKBP Bridge contributors',
    'version': (1, 4, 7), 'blender': (4, 2, 0), 'category': 'Import-Export',
    'description': '手动校验并合并网格，按当前网格结构整体导出到 Unity',
}
import bpy
from bpy.props import StringProperty, BoolProperty

class KKBPBRIDGE_OT_oneclick(bpy.types.Operator):
    bl_idname = 'export_scene.kkbp_one_click'
    bl_label = '整体导出'
    bl_description = '按当前网格结构整体导出可见角色；不自动分类、拆分或合并'
    def execute(self, context):
        try:
            from .one_click import run
            result = run(context)
            self.report({'INFO'}, '已按当前网格结构导出：' + context.scene.kkbridge_last_output)
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}

class KKBPBRIDGE_PT_panel(bpy.types.Panel):
    bl_label = 'KKBP → Unity 导出'
    bl_idname = 'KKBPBRIDGE_PT_panel'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'KKBP 导出'
    def draw(self, context):
        self.layout.label(text='插件版本：' + '.'.join(map(str, bl_info['version'])))
        self.layout.prop(context.scene, 'kkbridge_output')
        self.layout.prop(context.scene, 'kkbridge_remove_outlines')
        self.layout.operator(KKBPBRIDGE_OT_merge.bl_idname, text='合并选中网格（校验 UV 和材质）')
        self.layout.operator(KKBPBRIDGE_OT_oneclick.bl_idname, text='整体导出（保持当前网格）')

class KKBPBRIDGE_OT_merge(bpy.types.Operator):
    bl_idname = 'object.kkbp_safe_merge'
    bl_label = '合并选中网格'
    bl_description = '以活动物体为主合并；UV Warp 当前效果写入 UV（不保留动态控制）；校验材质、蒙皮与形态键，可用 Ctrl+Z 撤销'
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        try:
            # Blender may retain imported child modules after reinstalling a ZIP.
            import importlib
            from . import manual_merge
            merge_selected = importlib.reload(manual_merge).merge_selected
            baked = any(m.type == 'UV_WARP' for o in context.selected_objects for m in o.modifiers)
            name, count = merge_selected(context, remove_outlines=context.scene.kkbridge_remove_outlines)
            suffix = '；UV Warp 当前效果已写入 UV，动态控制已移除' if baked else ''
            if context.scene.kkbridge_remove_outlines: suffix += '；已移除 Blender Outline 描边'
            self.report({'INFO'}, f'已将 {count} 个网格合并为 {name}，UV 和材质校验通过' + suffix)
            return {'FINISHED'}
        except Exception as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}

CLASSES = (KKBPBRIDGE_OT_oneclick, KKBPBRIDGE_OT_merge, KKBPBRIDGE_PT_panel)
def register():
    import os
    bpy.types.Scene.kkbridge_output = StringProperty(name='输出目录', subtype='DIR_PATH',
        default=os.path.join(os.path.expanduser('~'), 'Documents', 'KKBPExports'))
    bpy.types.Scene.kkbridge_remove_outlines = BoolProperty(name='合并时移除 Blender 描边', default=False, description='移除名称含 Outline 的实体化修改器；Unity 描边需自行实现。保留基础网格、UV、蒙皮与形态键，可撤销')
    bpy.types.Scene.kkbridge_last_output = StringProperty(options={'HIDDEN'})
    for cls in CLASSES: bpy.utils.register_class(cls)
def unregister():
    for cls in reversed(CLASSES): bpy.utils.unregister_class(cls)
    for name in ('kkbridge_output', 'kkbridge_last_output', 'kkbridge_remove_outlines'):
        if hasattr(bpy.types.Scene, name): delattr(bpy.types.Scene, name)
