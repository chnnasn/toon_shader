"""Validate a join on disposable copies before committing the user's selection."""
import bpy
from collections import Counter, defaultdict
import math


def rounded(values):
    return tuple(round(float(v), 5) for v in values)


def faces(objects, include_normals=False):
    result = Counter()
    for obj in objects:
        mesh = obj.data
        normal_matrix = obj.matrix_world.to_3x3().inverted().transposed() if include_normals else None
        for poly in mesh.polygons:
            mat = obj.material_slots[poly.material_index].material
            corners = []
            for index in poly.loop_indices:
                vertex = mesh.vertices[mesh.loops[index].vertex_index]
                corner = (rounded(obj.matrix_world @ vertex.co),
                    tuple(rounded(uv.data[index].uv) for uv in mesh.uv_layers))
                if include_normals:
                    corner += (rounded((normal_matrix @ mesh.corner_normals[index].vector).normalized()),)
                corners.append(corner)
            result[(mat.as_pointer(), tuple(sorted(corners, key=lambda c: (c[1], c[0]))))] += 1
    return result


def vertices(objects, key_names):
    result = Counter()
    for obj in objects:
        keys = obj.data.shape_keys
        for v in obj.data.vertices:
            groups = tuple(sorted((obj.vertex_groups[g.group].name, round(g.weight, 5)) for g in v.groups))
            shapes = tuple(rounded(obj.matrix_world @ (keys.key_blocks[name].data[v.index].co
                if keys and name in keys.key_blocks else v.co)) for name in key_names)
            result[(rounded(obj.matrix_world @ v.co), groups, shapes)] += 1
    return result


def snapshots_equal(before, after, vertex=False):
    """Avoid false failures when float transforms cross a rounding boundary."""
    if before == after: return True
    def identity(item):
        return item[1] if vertex else (item[0], tuple(c[1] for c in item[1]))
    def coordinates(item):
        if vertex: return item[0] + tuple(v for shape in item[2] for v in shape)
        return tuple(v for c in item[1] for v in c[0])
    def normals_close(left, right):
        if vertex: return True
        for a,b in zip(left[1], right[1]):
            if len(a) != len(b): return False
            if len(a) < 3: continue
            na,nb=a[2],b[2]
            length=math.sqrt(sum(x*x for x in na)*sum(x*x for x in nb))
            if not math.isfinite(length): return False
            if length < 1e-12:
                if na != nb: return False
            # Recalculation on transformed near-degenerate triangles can
            # perturb normals; accept at most one degree of angular error.
            elif sum(x*y for x,y in zip(na,nb))/length < math.cos(math.radians(1)): return False
        return True
    candidates = defaultdict(list)
    for item, count in (after-before).items():
        candidates[identity(item)].extend([item]*count)
    for item, count in (before-after).items():
        target = coordinates(item); choices = candidates[identity(item)]
        for _ in range(count):
            match = next((i for i,c in enumerate(choices) if len(coordinates(c))==len(target) and normals_close(item,c) and
                all(math.isfinite(a) and math.isfinite(b) and abs(a-b)<=2.01e-5 for a,b in zip(coordinates(c),target))), None)
            if match is None: return False
            choices.pop(match)
    return not any(candidates.values())


def is_outline(mod):
    return mod.type == 'SOLIDIFY' and 'outline' in mod.name.lower()


def modifier_signature(obj, remove_outlines=False):
    result = []
    for mod in obj.modifiers:
        if remove_outlines and is_outline(mod): continue
        if mod.type == 'UV_WARP': continue  # Baked on disposable meshes.
        if not mod.show_viewport and not mod.show_render: continue
        values = []
        for prop in mod.bl_rna.properties:
            if prop.is_readonly or prop.identifier in ('name', 'show_expanded', 'is_active') or prop.type == 'COLLECTION':
                continue
            # These offsets are rebuilt per source mesh after joining. A prior
            # merge changes them, so comparing raw values blocks the next merge.
            if mod.type == 'SOLIDIFY' and prop.identifier in ('material_offset', 'material_offset_rim'):
                continue
            value = getattr(mod, prop.identifier)
            if prop.type == 'POINTER': value = value.as_pointer() if value else None
            elif getattr(prop, 'is_array', False): value = tuple(value)
            elif isinstance(value, set): value = tuple(sorted(value))
            values.append((prop.identifier, value))
        result.append((mod.type, tuple(values)))
    return result


def evaluated_faces(context, objects, render=False):
    """Check modifier output on copies, including render-only outline shells."""
    saved = [(m, m.show_viewport) for obj in objects for m in obj.modifiers]
    try:
        if render:
            for m, _ in saved: m.show_viewport = m.show_render
        context.view_layer.update()
        depsgraph = context.evaluated_depsgraph_get()
        result = Counter()
        for obj in objects:
            evaluated = obj.evaluated_get(depsgraph)
            result.update(faces([evaluated], include_normals=True))
        return result
    finally:
        for mod, visible in saved: mod.show_viewport = visible
        context.view_layer.update()


def bake_uv_warps(context, obj):
    warps = [m for m in obj.modifiers if m.type == 'UV_WARP']
    if not warps: return
    if any(m.show_viewport != m.show_render for m in warps):
        raise RuntimeError('UV Warp 的视图与渲染开关不同，无法写入同一套 UV；原网格未修改')
    saved = [(m, m.show_viewport) for m in obj.modifiers]
    try:
        for m, visible in saved:
            m.show_viewport = visible and m.type == 'UV_WARP'
        context.view_layer.update()
        evaluated = obj.evaluated_get(context.evaluated_depsgraph_get())
        mesh = evaluated.to_mesh(preserve_all_data_layers=True, depsgraph=context.evaluated_depsgraph_get())
        try:
            if len(mesh.loops) != len(obj.data.loops):
                raise RuntimeError('UV Warp 求值拓扑发生变化，原网格未修改')
            values = {}
            for layer in obj.data.uv_layers:
                source = mesh.uv_layers.get(layer.name)
                if source is None: raise RuntimeError('UV Warp 求值缺少 UV 层')
                values[layer.name] = [tuple(loop.uv) for loop in source.data]
        finally:
            evaluated.to_mesh_clear()
        for layer in obj.data.uv_layers:
            for loop, uv in zip(layer.data, values[layer.name]): loop.uv = uv
    finally:
        for m, visible in saved: m.show_viewport = visible
    for m in warps: obj.modifiers.remove(m)
    context.view_layer.update()


def merge_selected(context, remove_outlines=False):
    if context.mode != 'OBJECT':
        raise RuntimeError('请先切换到物体模式')
    selected = list(context.selected_objects)
    active = context.view_layer.objects.active
    if len(selected) < 2 or any(o.type != 'MESH' for o in selected) or active not in selected:
        raise RuntimeError('请至少选择两个网格，并把希望保留名称的网格设为活动物体')
    names = {o.get('name') for o in selected if o.get('name')}
    if len(names) > 1:
        raise RuntimeError('不能合并不同角色的网格')
    uv_names = [u.name for u in active.data.uv_layers]
    uv_render = next((u.name for u in active.data.uv_layers if u.active_render), None)
    rigs = set()
    key_names = set()
    settings = {}
    has_modifiers = any(m.type != 'ARMATURE' for o in selected for m in o.modifiers)
    supported = {'ARMATURE', 'SOLIDIFY', 'TRIANGULATE', 'MASK', 'WEIGHTED_NORMAL', 'UV_WARP'}
    signature = modifier_signature(active, remove_outlines) if has_modifiers else None
    solidify_materials = {}
    child_links = []
    source_keys = set()
    source_drivers = {}
    visited_trees = set()
    def check_coordinates(tree):
        if not tree or tree.as_pointer() in visited_trees: return
        visited_trees.add(tree.as_pointer())
        for node in tree.nodes:
            if node.type == 'TEX_COORD' and any(s.is_linked for s in node.outputs if s.name in ('Generated', 'Object')):
                raise RuntimeError('材质使用生成坐标／物体坐标，合并可能改变贴图位置；请先改用 UV 或烘焙')
            if node.type == 'OBJECT_INFO' and any(s.is_linked for s in node.outputs):
                raise RuntimeError('材质依赖物体信息，合并会改变结果；请先烘焙或移除此依赖')
            if node.type == 'GROUP': check_coordinates(node.node_tree)
    for obj in selected:
        ancestor = obj.parent
        while ancestor:
            if ancestor in selected:
                raise RuntimeError('所选网格之间存在父子关系，请分别合并或先清除父级并保持变换')
            ancestor = ancestor.parent
        if obj.library or obj.data.library or obj.constraints or obj.animation_data:
            raise RuntimeError(f'{obj.name} 存在链接数据、约束或物体动画，请先处理后再合并')
        for child in obj.children:
            if child in selected: continue
            if child.parent_type != 'OBJECT':
                raise RuntimeError(f'{obj.name} 的子物体“{child.name}”使用 {child.parent_type} 父级绑定，暂不支持安全合并')
            if obj != active:
                # Preserve the whole parent transform, including animated child
                # local transforms, rather than only its present world position.
                inverse = active.matrix_world.inverted() @ obj.matrix_world @ child.matrix_parent_inverse
                child_links.append((child, inverse))
        if [u.name for u in obj.data.uv_layers] != uv_names or next((u.name for u in obj.data.uv_layers if u.active_render), None) != uv_render:
            raise RuntimeError(f'{obj.name} 的 UV 层名称、顺序或渲染 UV 不一致；请先统一，避免通道错位')
        unsupported = [m for m in obj.modifiers if m.type not in supported and (m.show_viewport or m.show_render)]
        if unsupported:
            mod = unsupported[0]
            raise RuntimeError(f'{obj.name} 的修改器“{mod.name}”（{mod.type}）暂不支持安全合并；原网格未修改')
        if has_modifiers and modifier_signature(obj, remove_outlines) != signature:
            current = modifier_signature(obj, remove_outlines)
            detail = '修改器数量或顺序'
            for (kind, values), (other_kind, other_values) in zip(current, signature):
                if kind != other_kind:
                    detail = f'{kind} / {other_kind} 顺序'; break
                differences = [key for key, value in values if value != dict(other_values).get(key)]
                if differences:
                    detail = f'{kind}：{", ".join(differences[:3])}'; break
            raise RuntimeError(f'{obj.name} 与活动物体“{active.name}”仍有不兼容设置（{detail}）；原网格未修改')
        armatures = [m for m in obj.modifiers if m.type == 'ARMATURE']
        if len(armatures) > 1:
            raise RuntimeError('暂不支持多重骨架修改器')
        rig = armatures[0] if armatures else None
        rigs.add((rig.object if rig else None, rig.use_vertex_groups if rig else None,
                  rig.use_bone_envelopes if rig else None, rig.use_deform_preserve_volume if rig else None,
                  rig.vertex_group if rig else None, rig.invert_vertex_group if rig else None))
        if any(p.material_index >= len(obj.material_slots) or not obj.material_slots[p.material_index].material for p in obj.data.polygons):
            raise RuntimeError(f'{obj.name} 有未指定材质的面')
        for slot in obj.material_slots:
            if slot.material: check_coordinates(slot.material.node_tree)
        solidify = [m for m in obj.modifiers if m.type == 'SOLIDIFY' and not (remove_outlines and is_outline(m))]
        if len(solidify) > 1:
            raise RuntimeError('暂不支持叠加多个实体化修改器的材质偏移，请保持网格独立')
        if solidify:
            mod = solidify[0]; slots = [s.material for s in obj.material_slots]
            for poly in obj.data.polygons:
                i = poly.material_index; base = slots[i]
                shell = slots[max(0, min(i+mod.material_offset, len(slots)-1))]
                rim = slots[max(0, min(i+mod.material_offset_rim, len(slots)-1))]
                pair = (shell, rim)
                if base.as_pointer() in solidify_materials and solidify_materials[base.as_pointer()] != pair:
                    raise RuntimeError('同一材质对应不同描边材质，请先复制区分源材质或保持网格独立')
                solidify_materials[base.as_pointer()] = pair
        keys = obj.data.shape_keys
        if keys:
            if not keys.use_relative:
                raise RuntimeError('暂不支持绝对形态键合并')
            source_keys.add(keys)
            animation = keys.animation_data
            if animation:
                if animation.action or animation.nla_tracks:
                    raise RuntimeError('形态键包含 Action 或 NLA 动画片段，暂不支持合并；驱动器可以保留')
                for curve in animation.drivers:
                    identity = (curve.data_path, curve.array_index)
                    if identity in source_drivers and source_drivers[identity] != curve:
                        raise RuntimeError(f'多个网格对同一形态键属性设置了驱动：{curve.data_path}；原网格未修改')
                    source_drivers[identity] = curve
            for k in keys.key_blocks:
                state = (k.value, k.slider_min, k.slider_max, k.mute, k.vertex_group, k.relative_key.name)
                if k.name in settings and settings[k.name] != state:
                    raise RuntimeError(f'形态键 {k.name} 的值或设置不同，请先统一')
                settings[k.name] = state
                key_names.add(k.name)
    if len(rigs) != 1:
        raise RuntimeError('所选网格必须绑定同一个骨架，且骨架修改器设置一致')
    for other in context.scene.objects:
        if other in selected: continue
        for item in list(other.constraints) + list(other.modifiers):
            if getattr(item, 'target', None) in selected or getattr(item, 'object', None) in selected:
                raise RuntimeError('其他物体引用了所选网格，请先解除引用，避免合并后丢失关联')
    key_names = sorted(key_names)
    expected_faces = faces(selected)
    expected_vertices = vertices(selected, key_names)
    copies = []
    copied_meshes = []
    committed = False
    try:
        for obj in selected:
            clone = obj.copy(); clone.data = obj.data.copy()
            if remove_outlines:
                for mod in list(clone.modifiers):
                    if is_outline(mod): clone.modifiers.remove(mod)
            context.collection.objects.link(clone)
            # Freeze effective object-linked material slots into independent data.
            for slot, source_slot in zip(clone.material_slots, obj.material_slots):
                material = source_slot.material
                slot.link = 'DATA'; slot.material = material
            copies.append(clone); copied_meshes.append(clone.data)
        for obj in selected: obj.select_set(False)
        for obj in copies: obj.select_set(True)
        joined = copies[selected.index(active)]
        context.view_layer.objects.active = joined
        expected_view = evaluated_faces(context, copies) if has_modifiers else None
        expected_render = evaluated_faces(context, copies, render=True) if has_modifiers else None
        for clone in copies: bake_uv_warps(context, clone)
        expected_faces = faces(copies)
        bpy.ops.object.join()
        if solidify_materials:
            # Material offsets are slot-relative. Joining changes slot numbers,
            # so append parallel shell/rim palettes rather than reusing old offsets.
            slots = list(joined.data.materials); count = len(slots)
            for index in (0, 1):
                for mat in slots:
                    pair = solidify_materials.get(mat.as_pointer(), (mat, mat)) if mat else (None, None)
                    joined.data.materials.append(pair[index])
            mod = next(m for m in joined.modifiers if m.type == 'SOLIDIFY')
            mod.material_offset = count
            mod.material_offset_rim = count*2
        if joined.data.shape_keys:
            for k in joined.data.shape_keys.key_blocks:
                if k.name in settings:
                    value, low, high, mute, group, relative = settings[k.name]
                    k.slider_min=low; k.slider_max=high; k.value=value; k.mute=mute; k.vertex_group=group
                    k.relative_key=joined.data.shape_keys.key_blocks[relative]
        if source_drivers:
            target_keys = joined.data.shape_keys
            animation = target_keys.animation_data_create()
            for curve in list(animation.drivers): animation.drivers.remove(curve)
            for curve in source_drivers.values():
                copied = animation.drivers.from_existing(src_driver=curve)
                target_keys.path_resolve(copied.data_path)
                for variable in copied.driver.variables:
                    for target in variable.targets:
                        if target.id in source_keys: target.id = target_keys
            target_keys.update_tag()
            context.view_layer.update()
        if not snapshots_equal(expected_faces, faces([joined])):
            raise RuntimeError('合并校验失败：UV、材质或顶点位置发生变化，原网格已保留')
        if not snapshots_equal(expected_vertices, vertices([joined], key_names), vertex=True):
            raise RuntimeError('合并校验失败：蒙皮或形态键发生变化，原网格已保留')
        if has_modifiers and (not snapshots_equal(expected_view, evaluated_faces(context, [joined])) or
                              not snapshots_equal(expected_render, evaluated_faces(context, [joined], render=True))):
            raise RuntimeError('修改器效果校验失败：合并后描边／几何／材质对应发生变化，原网格已保留')
        merged = joined.data
        group_names = [g.name for g in joined.vertex_groups]
        old_groups = [g.name for g in active.vertex_groups]
        if group_names[:len(old_groups)] != old_groups:
            raise RuntimeError('合并后的顶点组顺序异常，原网格已保留')
        for name in group_names[len(old_groups):]: active.vertex_groups.new(name=name)
        active.data = merged
        for slot in active.material_slots: slot.link = 'DATA'
        for mod in list(active.modifiers):
            if mod.type == 'UV_WARP' or (remove_outlines and is_outline(mod)): active.modifiers.remove(mod)
        for source_mod, merged_mod in zip(active.modifiers, joined.modifiers):
            if source_mod.type == 'SOLIDIFY':
                source_mod.material_offset = merged_mod.material_offset
                source_mod.material_offset_rim = merged_mod.material_offset_rim
        if names: active['name'] = next(iter(names))
        for flag in ('body', 'hair', 'outfit'):
            if any(o.get(flag) for o in selected): active[flag] = True
        for child, inverse in child_links:
            child.parent = active
            child.matrix_parent_inverse = inverse
        # Keep eye/tear and other external drivers connected to the new keys.
        if source_keys and merged.shape_keys:
            for datablock in list(bpy.data.shape_keys) + list(bpy.data.objects):
                if datablock in source_keys: continue
                animation = datablock.animation_data
                if not animation: continue
                changed = False
                for curve in animation.drivers:
                    for variable in curve.driver.variables:
                        for target in variable.targets:
                            if target.id in source_keys:
                                target.id = merged.shape_keys
                                changed = True
                if changed: datablock.update_tag()
        # The shared mesh now belongs to active; remove only the disposable object.
        bpy.data.objects.remove(joined, do_unlink=True)
        for obj in selected:
            if obj != active: bpy.data.objects.remove(obj, do_unlink=True)
        active.select_set(True); context.view_layer.objects.active = active
        committed = True
        return active.name, len(selected)
    finally:
        for obj in copies:
            try:
                if obj.name in bpy.data.objects: bpy.data.objects.remove(obj, do_unlink=True)
            except ReferenceError: pass
        for mesh in copied_meshes:
            try:
                if mesh.users == 0: bpy.data.meshes.remove(mesh)
            except ReferenceError: pass
        if not committed:
            for obj in selected: obj.select_set(True)
            context.view_layer.objects.active = active
