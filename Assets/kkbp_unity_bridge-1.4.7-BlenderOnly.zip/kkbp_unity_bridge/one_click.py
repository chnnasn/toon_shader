"""Character-scoped collection; never include Rigify widgets or other characters."""
import bpy
from pathlib import Path
from datetime import datetime
from .exporter import export_bundle, DEFAULT_CHANNELS, editable_source

DEFAULT_RESOLUTION = 1024


def character_meshes(context):
    names = {o.get('name') for o in context.selected_objects if o.get('name')}
    if len(names) > 1:
        raise RuntimeError('Select only one KKBP character')
    name = next(iter(names), None) or getattr(getattr(context.scene, 'kkbp', None), 'character_name', '')
    if not name:
        candidates={o.get('name') for o in context.scene.objects if o.type=='MESH' and o.get('body') and o.get('name') and o.visible_get()}
        if len(candidates)==1:name=next(iter(candidates))
    if not name:
        raise RuntimeError('Select one KKBP character first')
    meshes = [o for o in context.scene.objects if o.type == 'MESH' and o.get('name') == name
              and (o.get('body') or o.get('outfit') or o.get('hair'))
              and not o.get('tears') and not o.get('tongue') and not o.get('gag')
              and o.get('part_group') != 'Auxiliary'
              and not o.hide_render and o.visible_get()]
    if not any(o.get('body') for o in meshes):
        raise RuntimeError('The character body must be visible')
    return name, meshes


def run(context):
    name, meshes = character_meshes(context)
    # KKBP's supported operator reconstructs configured nodes from the original
    # character export. Never substitute an unconfigured library material.
    for body in [o for o in meshes if o.get('body')]:
        for index, slot in enumerate(body.material_slots):
            mat = slot.material
            if not mat or mat.get('id') not in ('cf_m_body','cm_m_body') or mat.name.startswith('Outline '): continue
            try:
                editable_source(mat, DEFAULT_CHANNELS)
                continue
            except RuntimeError as exc:
                if 'baked body' not in str(exc): raise
            settings = getattr(context.scene, 'kkbp', None)
            if not settings or settings.character_name != name or not settings.import_dir or not Path(bpy.path.abspath(settings.import_dir)).is_dir():
                raise RuntimeError('KKBP original export folder is missing or belongs to another character. Set the correct KKBP import folder, then retry.')
            active = context.view_layer.objects.active
            selected = list(context.selected_objects)
            old_index = body.active_material_index
            old_slots = [s.material for s in body.material_slots]
            try:
                for o in selected: o.select_set(False)
                body.select_set(True); context.view_layer.objects.active = body
                body.active_material_index = index
                if bpy.ops.kkbp.editmaterial() != {'FINISHED'}:
                    raise RuntimeError('KKBP could not restore editable body material')
                editable_source(body.material_slots[index].material, DEFAULT_CHANNELS)
            except Exception:
                for s,m in zip(body.material_slots,old_slots):s.material=m
                raise
            finally:
                body.active_material_index = old_index
                for o in context.selected_objects:o.select_set(False)
                for o in selected:o.select_set(True)
                context.view_layer.objects.active = active
    directory = Path(bpy.path.abspath(context.scene.kkbridge_output))
    if not directory.is_absolute():
        raise RuntimeError('Set an absolute output folder first')
    import re
    safe = re.sub(r'[^\w-]+', '_', name)
    path = directory / (safe + '_' + datetime.now().strftime('%Y%m%d_%H%M%S_%f') + '.fbx')
    result = export_bundle(context, str(path), DEFAULT_RESOLUTION,
                           DEFAULT_CHANNELS, direct_unity=True, objects_override=meshes)
    context.scene.kkbridge_last_output = str(path.with_suffix(''))
    return result
