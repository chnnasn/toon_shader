import copy, json, uuid
from pathlib import Path

def build_graph(path, channels, include_guid):
    def decode(path):
        decoder=json.JSONDecoder(); text=path.read_text(encoding='utf-8-sig'); result=[]
        while text.strip():
            text=text.lstrip(); obj,end=decoder.raw_decode(text); result.append(obj); text=text[end:]
        return result
    
    source=decode(Path(__file__).parent/'templates/LitFull.shadergraph')
    masterSource=decode(Path(__file__).parent/'templates/Unlit.shadergraph')
    original={o['m_ObjectId']:o for o in masterSource}
    graph=copy.deepcopy(masterSource[0]); output=[]
    uid=lambda:uuid.uuid4().hex
    ref=lambda o:{'m_Id':o['m_ObjectId']}
    
    def exemplar(typename):
        return next(o for o in source if o['m_Type'].endswith('.'+typename))
    
    def clone(o):
        result=copy.deepcopy(o); result['m_ObjectId']=uid(); return result
    
    # Preserve every target, master block, context and all their backing slot objects.
    blocks=[original[r['m_Id']] for r in graph['m_Nodes'] if original[r['m_Id']]['m_Type'].endswith('.BlockNode')]
    keep={o['m_ObjectId'] for o in blocks}
    keep.update(r['m_Id'] for o in blocks for r in o['m_Slots'])
    ordinary={r['m_Id'] for r in graph['m_Nodes']}-keep
    old_slots={r['m_Id'] for k in ordinary for r in original[k].get('m_Slots',[])}
    old_props={r['m_Id'] for r in graph['m_Properties']+graph['m_Keywords']+graph.get('m_CategoryData',[])+graph.get('m_GroupDatas',[])}
    for o in masterSource[1:]:
        if o['m_ObjectId'] not in ordinary|old_slots|old_props:
            retained=copy.deepcopy(o)
            if retained['m_Type']=='UnityEditor.Rendering.Universal.ShaderGraph.UniversalTarget':
                # The stock template overrides this with LitShader, which requires
                # fixed URP Lit properties removed by this custom graph. Let the
                # UniversalLitSubTarget select its native ShaderGraphLitGUI instead.
                retained['m_CustomEditorGUI']=''
            output.append(retained)
    graph['m_Nodes']=[ref(o) for o in blocks]
    for key in ('m_Properties','m_Keywords','m_CategoryData','m_GroupDatas','m_StickyNoteDatas','m_Edges'):
        graph[key]=[]
    graph['m_Path']='KKBP Export'
    graph['m_Precision']=0
    
    def slot(kind,index,name,out=False):
        s=clone(exemplar(kind+'MaterialSlot'))
        s.update(m_Id=index,m_DisplayName=name,m_ShaderOutputName=name,m_SlotType=1 if out else 0,m_StageCapability=2)
        output.append(s); return s
    
    def node(kind,name,x,y):
        base=clone(exemplar('PropertyNode'))
        base.pop('m_Property',None)
        base.update(m_Type='UnityEditor.ShaderGraph.'+kind,m_Name=name,m_Group={'m_Id':''},m_Slots=[],m_Precision=1)
        base['m_DrawState']['m_Position'].update(x=x,y=y,width=230,height=160)
        output.append(base); graph['m_Nodes'].append(ref(base)); return base
    
    def edge(a,ai,b,bi):
        graph['m_Edges'].append({'m_OutputSlot':{'m_Node':ref(a),'m_SlotId':ai},'m_InputSlot':{'m_Node':ref(b),'m_SlotId':bi}})
    
    def property_node(kind,name,reference,value,y):
        prop=clone(exemplar(kind+'ShaderProperty'))
        prop.update(m_Name=name,m_OverrideReferenceName=reference,m_DefaultReferenceName=reference,m_RefNameGeneratedByDisplayName=name,m_Guid={'m_GuidSerialized':str(uuid.uuid4())},m_Value=value)
        if kind=='Vector1': prop['m_FloatType']=0
        if kind=='Texture2D': prop.update(m_DefaultType=1 if reference=='_NormalMap' else 0,isMainTexture=reference=='_BaseMap')
        if kind=='Color': prop['isMainColor']=reference=='_Tint'
        output.append(prop); graph['m_Properties'].append(ref(prop))
        p=node('PropertyNode',name,-1050,y); p['m_Property']=ref(prop)
        s=slot('Vector4' if kind=='Color' else kind,0,'Out',True); p['m_Slots']=[ref(s)]
        return p
    
    c=node('CustomFunctionNode','KKBP editable color reconstruction',0,0)
    c.update(m_SGVersion=1,m_SourceType=0,m_FunctionName='KKBPColor',m_FunctionSource=include_guid,m_FunctionSourceUsePragmas=False,m_FunctionBody='')
    ports=[]
    def inp(name,kind,n):
        s=slot(kind,len(ports),name); c['m_Slots'].append(ref(s));ports.append((kind,name));edge(n,0,c,s['m_Id'])
    for kind,name in [('PositionNode','PositionWS'),('NormalVectorNode','NormalWS'),('ViewDirectionNode','ViewWS'),('UVNode','UV')]:
        n=node(kind,name,-650,len(ports)*180); n['m_Space']=2;n['m_OutputChannel']=0
        n['m_Slots']=[ref(slot('Vector4' if kind=='UVNode' else 'Vector3',0,'Out',True))]
        if kind=='PositionNode':n['m_SGVersion']=1
        inp(name,'Vector2' if kind=='UVNode' else 'Vector3',n)
    def prop(kind,name,reference,value,hidden=False):
        n=property_node(kind,name,reference,value,len(ports)*160)
        for o in output:
            if o.get('m_OverrideReferenceName')==reference:o['m_Hidden']=hidden
        inp(reference[1:],'Vector4' if kind=='Color' else kind,n)
    prop('Color','UV transform','_BridgeUV',dict(r=1,g=1,b=0,a=0),True)
    prop('Color','Overall tint','_Tint',dict(r=1,g=1,b=1,a=1))
    prop('Color','Skin texture tint','_SkinTint',dict(r=1,g=1,b=1,a=1),not bool(channels))
    for name,val in [('Threshold',0),('Softness',.05),('BridgePreview',0)]:prop('Vector1',name,'_'+name,val,name=='BridgePreview')
    for name in ['Opacity','LightBase','DarkBase']+[v+'Weight'+str(i) for v in ('Light','Dark') for i in range(len(channels))]:
        prop('Texture2D',name,'_'+name,{'m_SerializedTexture':'','m_Guid':''},True)
    for v in ('Light','Dark'):
        for i,label in enumerate(channels):prop('Color',label+' ('+v+')','_Bridge'+v+'Color'+str(i),dict(r=1,g=1,b=1,a=1))
    col=slot('Vector3',len(ports),'Color',True);alpha=slot('Vector1',len(ports)+1,'Alpha',True);c['m_Slots'] += [ref(col),ref(alpha)]
    bn={b['m_Name']:b for b in blocks}
    edge(c,col['m_Id'],bn['SurfaceDescription.BaseColor'],0);edge(c,alpha['m_Id'],bn['SurfaceDescription.Alpha'],0)
    for name,val in [('AlphaClipThreshold',.5)]:
        if 'SurfaceDescription.'+name not in bn: continue
        n=node('Vector1Node',name+' default',450,500+len(graph['m_Nodes'])*20);n['m_Value']=val
        a=slot('Vector1',0,'Out',True);b=slot('Vector1',1,'X');b['m_Value']=val;b['m_DefaultValue']=val;n['m_Slots']=[ref(a),ref(b)];edge(n,0,bn['SurfaceDescription.'+name],0)
    for o in output:
        if o['m_Type'].endswith('UniversalTarget'):o['m_AlphaClip']=True;o['m_AllowMaterialOverride']=False
    for name in ('_SpecGlossMap','_MetallicGlossMap'):
        p=clone(exemplar('Texture2DShaderProperty'));p.update(m_Name=name,m_OverrideReferenceName=name,m_DefaultReferenceName=name,m_Guid={'m_GuidSerialized':str(uuid.uuid4())},m_Value={'m_SerializedTexture':'','m_Guid':''},m_Hidden=True);output.append(p);graph['m_Properties'].append(ref(p))
    cat={'m_SGVersion':0,'m_Type':'UnityEditor.ShaderGraph.CategoryData','m_ObjectId':uid(),'m_Name':'KKBP Editable Colors','m_ChildObjectList':graph['m_Properties']};output.append(cat);graph['m_CategoryData']=[ref(cat)]
    Path(path).write_text('\n\n'.join(json.dumps(o,indent=2) for o in [graph]+output)+'\n',encoding='utf8')
    types={'Vector2':'float2','Vector3':'float3','Vector4':'float4','Vector1':'float','Texture2D':'UnityTexture2D'}
    args=', '.join(types[k]+' '+n for k,n in ports)+', out float3 Color, out float Alpha'
    body='float2 uv=BridgePreview>.5?UV:UV*BridgeUV.xy+BridgeUV.zw;\n'
    body+='Alpha=SAMPLE_TEXTURE2D(Opacity.tex,Opacity.samplerstate,uv).r;\n'
    for v in ('Light','Dark'):
        body+=f'float3 {v}Result=SAMPLE_TEXTURE2D({v}Base.tex,{v}Base.samplerstate,uv).rgb*SkinTint.rgb;\n'
        for i in range(len(channels)):
            body+=f'{v}Result+=SAMPLE_TEXTURE2D({v}Weight{i}.tex,LightBase.samplerstate,uv).rgb*Bridge{v}Color{i}.rgb;\n'
    body+='''if(BridgePreview>.5){Color=BridgePreview>1.5?DarkResult:LightResult;return;}
#ifdef SHADERGRAPH_PREVIEW
Color=LightResult*Tint.rgb;
#else
Light mainLight=GetMainLight();
float band=smoothstep(Threshold-Softness,Threshold+Softness,dot(normalize(NormalWS),mainLight.direction));
Color=max(0,lerp(DarkResult,LightResult,band))*Tint.rgb*max(mainLight.color,SampleSH(normalize(NormalWS)));
#endif
'''
    return '#ifndef KKBP_COLOR_'+include_guid+'\n#define KKBP_COLOR_'+include_guid+'\n#ifndef SHADERGRAPH_PREVIEW\n#include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Lighting.hlsl"\n#endif\nvoid KKBPColor_float('+args+'){\n'+body+'}\n#endif\n'
