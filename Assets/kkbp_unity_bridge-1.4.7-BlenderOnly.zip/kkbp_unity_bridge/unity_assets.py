"""Write native Unity assets from Blender. No Unity process or Editor scripts required.

Importer metadata follows Unity 6000.4 serialization, verified by native reimport.
Only new export directories are written. GUIDs are unique per export and all
cross-file references are emitted together. Float/color textures stay linear.
"""
import json
import math
from pathlib import Path
import re
import uuid

TEMPLATES = Path(__file__).parent / 'templates'


def q(value):
    return json.dumps(str(value), ensure_ascii=False)


def number(value):
    value = float(value)
    if not math.isfinite(value):
        raise ValueError('Non-finite material parameter')
    return format(value, '.9g')


def gamma(value):
    return 12.92 * value if value <= .0031308 else 1.055 * value ** (1/2.4) - .055


def rgba(color, linear_to_gamma=False):
    values = [float(color.get(k, 1 if k == 'a' else 0)) for k in ('r','g','b','a')]
    if linear_to_gamma:
        values[:3] = [gamma(v) for v in values[:3]]
    return '{' + ', '.join(f'{k}: {number(v)}' for k, v in zip(('r','g','b','a'), values)) + '}'


def meta(path, guid, body):
    path.with_name(path.name + '.meta').write_text(f'fileFormatVersion: 2\nguid: {guid}\n{body}', encoding='utf8')


def texture_meta(path, guid, size):
    size = 2 ** math.ceil(math.log2(size))
    meta(path, guid, f'''TextureImporter:
  serializedVersion: 13
  internalIDToNameTable: []
  externalObjects: {{}}
  mipmaps:
    mipMapMode: 0
    enableMipMap: 1
    sRGBTexture: 0
  isReadable: 0
  textureType: 0
  textureShape: 1
  maxTextureSize: {size}
  alphaUsage: 0
  alphaIsTransparency: 0
  textureSettings:
    serializedVersion: 2
    filterMode: 1
    aniso: 1
    mipBias: 0
    wrapU: 1
    wrapV: 1
    wrapW: 1
  nPOTScale: 0
  platformSettings:
  - serializedVersion: 4
    buildTarget: DefaultTexturePlatform
    maxTextureSize: {size}
    resizeAlgorithm: 0
    textureFormat: -1
    textureCompression: 0
    compressionQuality: 50
    crunchedCompression: 0
    overridden: 0
  userData:
  assetBundleName:
  assetBundleVariant:
''')


def shader_text(template, channels, guid):
    text = template.replace('Shader "KKBP Bridge/Editable Toon URP"', f'Shader "KKBP Export/{guid}"')
    text = re.sub(r'^\s*CustomEditor\s+"[^"]+"\s*$', '', text, flags=re.M)
    # Each channel signature has its own native property labels. There is no custom GUI script.
    for variant in ('Light','Dark'):
        for i in range(8):
            prop = f'_Bridge{variant}Color{i}'
            if i < len(channels):
                label = f'{channels[i]} ({variant})'
                text = text.replace(f'("{variant} color {i+1}", Color)', f'({q(label)}, Color)')
            else:
                text = re.sub(rf'^(\s*)({prop}\s*\()', r'\1[HideInInspector] \2', text, flags=re.M)
    # Texture bindings are generated; only useful colors and lighting controls appear.
    text = re.sub(r'^(\s*)(_\w+\s*\([^\n]+, 2D\))', r'\1[HideInInspector] \2', text, flags=re.M)
    return text


def write_unity_assets(directory, model_filename, materials, resolution):
    directory = Path(directory)
    (directory/'Materials').mkdir()
    (directory/'Shaders').mkdir()
    shader_template = (TEMPLATES/'EditableToon.shader').read_text(encoding='utf8')
    model_template = (TEMPLATES/'ModelImporter.meta.template').read_text(encoding='utf8')
    texture_guids, shaders, remaps = {}, {}, []
    for i, material in enumerate(materials):
        channels = tuple(material['channels'])
        if channels not in shaders:
            guid = uuid.uuid4().hex
            from .shadergraph import build_graph
            file = directory/'Shaders'/f'KKBP_{len(shaders):02d}.shadergraph'
            include_guid = uuid.uuid4().hex
            hlsl = build_graph(file, channels, include_guid)
            include = file.with_suffix('.hlsl')
            include.write_text(hlsl, encoding='utf8')
            meta(include, include_guid, 'ShaderIncludeImporter:\n  externalObjects: {}\n')
            meta(file, guid, 'ScriptedImporter:\n  internalIDToNameTable: []\n  externalObjects: {}\n  serializedVersion: 2\n  userData:\n  assetBundleName:\n  assetBundleVariant:\n  script: {fileID: 11500000, guid: 625f186215c104763be7675aa2d941aa, type: 3}\n')
            shaders[channels] = guid
        shader_guid = shaders[channels]
        textures = {'_Opacity': material['opacity']}
        colors = {'_Tint': {'r':1,'g':1,'b':1,'a':1}, '_SkinTint': {'r':1,'g':1,'b':1,'a':1}, '_ShadowTint': {'r':.57,'g':.28,'b':.32,'a':1}}
        for variant in material['variants']:
            prefix = 'Light' if variant['name'] == 'light' else 'Dark'
            textures['_'+prefix+'Base'] = variant['base']
            for slot, filename in enumerate(variant['weights']):
                textures[f'_{prefix}Weight{slot}'] = filename
            for slot, color in enumerate(variant['colors']):
                colors[f'_Bridge{prefix}Color{slot}'] = color
        texture_lines = []
        for prop, relative in textures.items():
            path = (directory/relative).resolve()
            if not path.is_relative_to(directory.resolve()) or path.suffix.lower() != '.exr' or not path.is_file():
                raise ValueError(f'Missing/invalid export texture: {relative}')
            if relative not in texture_guids:
                texture_guids[relative] = uuid.uuid4().hex
                texture_meta(path, texture_guids[relative], resolution)
            texture_lines.extend([f'    - {prop}:', f'        m_Texture: {{fileID: 2800000, guid: {texture_guids[relative]}, type: 3}}',
                                  '        m_Scale: {x: 1, y: 1}', '        m_Offset: {x: 0, y: 0}'])
        safe = re.sub(r'[^\w-]+', '_', material['name'])[:80]
        filename = f'm{i:03d}_{safe}.mat'
        material_guid = uuid.uuid4().hex
        color_lines = [f'    - {prop}: {rgba(color, True)}' for prop,color in colors.items()]
        uv = material.get('uvTransform', {'x':1,'y':1,'z':0,'w':0})
        color_lines.append('    - _BridgeUV: ' + rgba(dict(zip(('r','g','b','a'), (uv[k] for k in ('x','y','z','w'))))))
        content = f'''%YAML 1.1
%TAG !u! tag:unity3d.com,2011:
--- !u!21 &2100000
Material:
  serializedVersion: 8
  m_ObjectHideFlags: 0
  m_CorrespondingSourceObject: {{fileID: 0}}
  m_PrefabInstance: {{fileID: 0}}
  m_PrefabAsset: {{fileID: 0}}
  m_Name: {q(Path(filename).stem)}
  m_Shader: {{fileID: -6465566751694194690, guid: {shader_guid}, type: 3}}
  m_Parent: {{fileID: 0}}
  m_ModifiedSerializedProperties: 0
  m_ValidKeywords: []
  m_InvalidKeywords: []
  m_LightmapFlags: 4
  m_EnableInstancingVariants: 0
  m_DoubleSidedGI: 0
  m_CustomRenderQueue: -1
  stringTagMap:
    KKBridgeChannels: {q('|'.join(channels))}
    KKBridgeSourceMaterial: {q(material['name'])}
  disabledShaderPasses: []
  m_LockedProperties:
  m_SavedProperties:
    serializedVersion: 3
    m_TexEnvs:
{chr(10).join(texture_lines)}
    m_Ints: []
    m_Floats:
    - _BridgePreview: 0
    - _Cull: 0
    - _Cutoff: {'.5' if material['cutout'] else '0'}
    - _Softness: .05
    - _Threshold: 0
    m_Colors:
{chr(10).join(color_lines)}
  m_BuildTextureStacks: []
  m_AllowLocking: 1
'''
        file = directory/'Materials'/filename
        file.write_text(content, encoding='utf8')
        meta(file, material_guid, 'NativeFormatImporter:\n  externalObjects: {}\n  mainObjectFileID: 2100000\n  userData:\n  assetBundleName:\n  assetBundleVariant:\n')
        material['unityMaterial'] = 'Materials/'+filename
        remaps.extend(['  - first:', '      type: UnityEngine:Material', '      assembly: UnityEngine.CoreModule',
                       '      name: '+q(material['name']), f'    second: {{fileID: 2100000, guid: {material_guid}, type: 2}}'])
    model_meta = model_template.replace('__GUID__',uuid.uuid4().hex).replace('  externalObjects: {}', '  externalObjects:\n'+'\n'.join(remaps))
    (directory/(model_filename+'.meta')).write_text(model_meta,encoding='utf8')
    (directory/'README.txt').write_text(
        'Blender → Unity URP (Linear)\n\n把此整个文件夹复制进 Unity 的 Assets。务必保留所有 .meta 文件。\n'
        f'等待原生导入完成后，将 {model_filename} 拖入场景；材质会自动关联。\n'
        '打开 Materials 中的身体材质，直接调整 Nipple base / base 2 / shine / rim 等颜色。\n'
        'Light 为亮面，Dark 为阴影面。不需要任何 Unity 导入插件或 C# 脚本。\n'
        '不要只复制 FBX，也不要删除 .meta，否则自动材质关联会丢失。\n'
        '支持 URP，当前验证 Unity 6000.4。其他管线不适用。\n'
        '不包含法线贴图、描边、物理和动画片段。重叠 UV 须具有相同材质结果。\n', encoding='utf8')
