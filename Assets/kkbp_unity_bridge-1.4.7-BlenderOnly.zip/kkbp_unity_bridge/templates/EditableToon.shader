Shader "KKBP Bridge/Editable Toon URP"
{
 Properties {
 _LightBase ("Light base", 2D) = "white" {}
_LightWeight0 ("Light response 1", 2D) = "black" {}
_BridgeLightColor0 ("Light color 1", Color) = (0,0,0,1)
_LightWeight1 ("Light response 2", 2D) = "black" {}
_BridgeLightColor1 ("Light color 2", Color) = (0,0,0,1)
_LightWeight2 ("Light response 3", 2D) = "black" {}
_BridgeLightColor2 ("Light color 3", Color) = (0,0,0,1)
_LightWeight3 ("Light response 4", 2D) = "black" {}
_BridgeLightColor3 ("Light color 4", Color) = (0,0,0,1)
_LightWeight4 ("Light response 5", 2D) = "black" {}
_BridgeLightColor4 ("Light color 5", Color) = (0,0,0,1)
_LightWeight5 ("Light response 6", 2D) = "black" {}
_BridgeLightColor5 ("Light color 6", Color) = (0,0,0,1)
_LightWeight6 ("Light response 7", 2D) = "black" {}
_BridgeLightColor6 ("Light color 7", Color) = (0,0,0,1)
_LightWeight7 ("Light response 8", 2D) = "black" {}
_BridgeLightColor7 ("Light color 8", Color) = (0,0,0,1)
_DarkBase ("Dark base", 2D) = "white" {}
_DarkWeight0 ("Dark response 1", 2D) = "black" {}
_BridgeDarkColor0 ("Dark color 1", Color) = (0,0,0,1)
_DarkWeight1 ("Dark response 2", 2D) = "black" {}
_BridgeDarkColor1 ("Dark color 2", Color) = (0,0,0,1)
_DarkWeight2 ("Dark response 3", 2D) = "black" {}
_BridgeDarkColor2 ("Dark color 3", Color) = (0,0,0,1)
_DarkWeight3 ("Dark response 4", 2D) = "black" {}
_BridgeDarkColor3 ("Dark color 4", Color) = (0,0,0,1)
_DarkWeight4 ("Dark response 5", 2D) = "black" {}
_BridgeDarkColor4 ("Dark color 5", Color) = (0,0,0,1)
_DarkWeight5 ("Dark response 6", 2D) = "black" {}
_BridgeDarkColor5 ("Dark color 6", Color) = (0,0,0,1)
_DarkWeight6 ("Dark response 7", 2D) = "black" {}
_BridgeDarkColor6 ("Dark color 7", Color) = (0,0,0,1)
_DarkWeight7 ("Dark response 8", 2D) = "black" {}
_BridgeDarkColor7 ("Dark color 8", Color) = (0,0,0,1)
 _Opacity ("Opacity", 2D) = "white" {}
 _Tint ("Overall tint", Color) = (1,1,1,1)
 _Cutoff ("Alpha cutoff (0 = opaque)", Range(0,1)) = 0
 _Threshold ("Shadow threshold", Range(-1,1)) = 0
 _Softness ("Shadow softness", Range(0.001,1)) = 0.05
 [HideInInspector] _BridgePreview ("Validation preview", Float) = 0
 [HideInInspector] _BridgeUV ("UV transform", Vector) = (1,1,0,0)
 [Enum(UnityEngine.Rendering.CullMode)] _Cull ("Cull", Float) = 0
 }
 SubShader {
 Tags { "RenderPipeline"="UniversalPipeline" "RenderType"="TransparentCutout" "Queue"="AlphaTest" }
 Cull [_Cull]
 HLSLINCLUDE
 #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
 #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Lighting.hlsl"
 TEXTURE2D(_LightBase);
TEXTURE2D(_LightWeight0);
TEXTURE2D(_LightWeight1);
TEXTURE2D(_LightWeight2);
TEXTURE2D(_LightWeight3);
TEXTURE2D(_LightWeight4);
TEXTURE2D(_LightWeight5);
TEXTURE2D(_LightWeight6);
TEXTURE2D(_LightWeight7);
TEXTURE2D(_DarkBase);
TEXTURE2D(_DarkWeight0);
TEXTURE2D(_DarkWeight1);
TEXTURE2D(_DarkWeight2);
TEXTURE2D(_DarkWeight3);
TEXTURE2D(_DarkWeight4);
TEXTURE2D(_DarkWeight5);
TEXTURE2D(_DarkWeight6);
TEXTURE2D(_DarkWeight7);
 TEXTURE2D(_Opacity);
 SAMPLER(sampler_LightBase);
 SAMPLER(sampler_Opacity);
 CBUFFER_START(UnityPerMaterial)
 float4 _BridgeLightColor0;
float4 _BridgeLightColor1;
float4 _BridgeLightColor2;
float4 _BridgeLightColor3;
float4 _BridgeLightColor4;
float4 _BridgeLightColor5;
float4 _BridgeLightColor6;
float4 _BridgeLightColor7;
float4 _BridgeDarkColor0;
float4 _BridgeDarkColor1;
float4 _BridgeDarkColor2;
float4 _BridgeDarkColor3;
float4 _BridgeDarkColor4;
float4 _BridgeDarkColor5;
float4 _BridgeDarkColor6;
float4 _BridgeDarkColor7;
 float4 _Tint, _BridgeUV;
 float _Cutoff, _Threshold, _Softness, _Cull, _BridgePreview;
 CBUFFER_END
 struct Attributes { float4 positionOS:POSITION; float3 normalOS:NORMAL; float2 uv:TEXCOORD0; UNITY_VERTEX_INPUT_INSTANCE_ID };
 struct Varyings { float4 positionCS:SV_POSITION; float3 positionWS:TEXCOORD1; float3 normalWS:TEXCOORD2; float2 uv:TEXCOORD0; UNITY_VERTEX_OUTPUT_STEREO };
 Varyings vert(Attributes v) {
   Varyings o; UNITY_SETUP_INSTANCE_ID(v); UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o);
   VertexPositionInputs p=GetVertexPositionInputs(v.positionOS.xyz);
   o.positionCS=p.positionCS; o.positionWS=p.positionWS;
   o.normalWS=TransformObjectToWorldNormal(v.normalOS);
   o.uv=_BridgePreview>.5?v.uv:v.uv*_BridgeUV.xy+_BridgeUV.zw;return o;
 }
 void ClipOpacity(float2 uv) { clip(SAMPLE_TEXTURE2D(_Opacity,sampler_Opacity,uv).r-_Cutoff); }
 ENDHLSL
 Pass {
 Name "Forward" Tags { "LightMode"="UniversalForward" }
 HLSLPROGRAM
 #pragma target 3.5
 #pragma vertex vert
 #pragma fragment frag
 #pragma multi_compile_instancing
 #pragma multi_compile _ _MAIN_LIGHT_SHADOWS _MAIN_LIGHT_SHADOWS_CASCADE _MAIN_LIGHT_SHADOWS_SCREEN
 #pragma multi_compile_fragment _ _SHADOWS_SOFT
 half4 frag(Varyings i):SV_Target {
   UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(i);
   ClipOpacity(i.uv);
   float3 light = SAMPLE_TEXTURE2D(_LightBase, sampler_LightBase, i.uv).rgb;
light += SAMPLE_TEXTURE2D(_LightWeight0, sampler_LightBase, i.uv).rgb * _BridgeLightColor0.rgb;
light += SAMPLE_TEXTURE2D(_LightWeight1, sampler_LightBase, i.uv).rgb * _BridgeLightColor1.rgb;
light += SAMPLE_TEXTURE2D(_LightWeight2, sampler_LightBase, i.uv).rgb * _BridgeLightColor2.rgb;
light += SAMPLE_TEXTURE2D(_LightWeight3, sampler_LightBase, i.uv).rgb * _BridgeLightColor3.rgb;
light += SAMPLE_TEXTURE2D(_LightWeight4, sampler_LightBase, i.uv).rgb * _BridgeLightColor4.rgb;
light += SAMPLE_TEXTURE2D(_LightWeight5, sampler_LightBase, i.uv).rgb * _BridgeLightColor5.rgb;
light += SAMPLE_TEXTURE2D(_LightWeight6, sampler_LightBase, i.uv).rgb * _BridgeLightColor6.rgb;
light += SAMPLE_TEXTURE2D(_LightWeight7, sampler_LightBase, i.uv).rgb * _BridgeLightColor7.rgb;
float3 dark = SAMPLE_TEXTURE2D(_DarkBase, sampler_LightBase, i.uv).rgb;
dark += SAMPLE_TEXTURE2D(_DarkWeight0, sampler_LightBase, i.uv).rgb * _BridgeDarkColor0.rgb;
dark += SAMPLE_TEXTURE2D(_DarkWeight1, sampler_LightBase, i.uv).rgb * _BridgeDarkColor1.rgb;
dark += SAMPLE_TEXTURE2D(_DarkWeight2, sampler_LightBase, i.uv).rgb * _BridgeDarkColor2.rgb;
dark += SAMPLE_TEXTURE2D(_DarkWeight3, sampler_LightBase, i.uv).rgb * _BridgeDarkColor3.rgb;
dark += SAMPLE_TEXTURE2D(_DarkWeight4, sampler_LightBase, i.uv).rgb * _BridgeDarkColor4.rgb;
dark += SAMPLE_TEXTURE2D(_DarkWeight5, sampler_LightBase, i.uv).rgb * _BridgeDarkColor5.rgb;
dark += SAMPLE_TEXTURE2D(_DarkWeight6, sampler_LightBase, i.uv).rgb * _BridgeDarkColor6.rgb;
dark += SAMPLE_TEXTURE2D(_DarkWeight7, sampler_LightBase, i.uv).rgb * _BridgeDarkColor7.rgb;
   if (_BridgePreview > 1.5) return half4(dark,1);
   if (_BridgePreview > .5) return half4(light,1);
   Light mainLight=GetMainLight(TransformWorldToShadowCoord(i.positionWS));
   float ndl=dot(normalize(i.normalWS),mainLight.direction);
   float band=smoothstep(_Threshold-_Softness,_Threshold+_Softness,ndl)*mainLight.shadowAttenuation;
   float3 illumination=max(mainLight.color, SampleSH(normalize(i.normalWS)));
   return half4(max(0,lerp(dark,light,band))*_Tint.rgb*illumination,1);
 }
 ENDHLSL
 }
 Pass {
 Name "DepthOnly" Tags { "LightMode"="DepthOnly" }
 ZWrite On ColorMask R
 HLSLPROGRAM
 #pragma target 3.5
 #pragma vertex vert
 #pragma fragment depth
 #pragma multi_compile_instancing
 half4 depth(Varyings i):SV_Target { ClipOpacity(i.uv); return 0; }
 ENDHLSL
 }
 Pass {
 Name "ShadowCaster" Tags { "LightMode"="ShadowCaster" }
 ZWrite On ZTest LEqual ColorMask 0
 HLSLPROGRAM
 #pragma target 3.5
 #pragma vertex shadowVert
 #pragma fragment depth
 #pragma multi_compile_instancing
 #pragma multi_compile_vertex _ _CASTING_PUNCTUAL_LIGHT_SHADOW
 float3 _LightDirection;
 float3 _LightPosition;
 Varyings shadowVert(Attributes v) {
   Varyings o=vert(v);
   float3 direction=_LightDirection;
   #if defined(_CASTING_PUNCTUAL_LIGHT_SHADOW)
   direction=normalize(_LightPosition-o.positionWS);
   #endif
   o.positionCS=TransformWorldToHClip(ApplyShadowBias(o.positionWS,o.normalWS,direction));
   #if UNITY_REVERSED_Z
   o.positionCS.z=min(o.positionCS.z,UNITY_NEAR_CLIP_VALUE*o.positionCS.w);
   #else
   o.positionCS.z=max(o.positionCS.z,UNITY_NEAR_CLIP_VALUE*o.positionCS.w);
   #endif
   return o;
 }
 half4 depth(Varyings i):SV_Target { ClipOpacity(i.uv); return 0; }
 ENDHLSL
 }
 }
 CustomEditor "KKBPBridge.Editor.BridgeShaderGUI"
}
